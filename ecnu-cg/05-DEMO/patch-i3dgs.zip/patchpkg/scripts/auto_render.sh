#!/bin/bash
# 训练完成后接力：自动沿轨迹渲染漫游视频，并汇总一份 results/SUMMARY.txt
ROOT=/home/hjadmin/zw/ecnu/ecnv-cg
PY=/home/hjadmin/anaconda3/envs/i3dgs/bin/python
LOG=$ROOT/logs/auto_render.log
export CUDA_VISIBLE_DEVICES=1
export TORCH_CUDA_ARCH_LIST="12.0"
export PYTHONUNBUFFERED=1
cd "$ROOT/i3dgs" || exit 1
echo "[$(date '+%F %T')] render watchdog started" >> "$LOG"

while true; do
  RUNNING=$(pgrep -f "train.py -s .*garden" | wc -l)
  DONE=""
  for ds in 4 8; do
    D=$ROOT/results/garden_ds$ds
    if [ -d "$D/point_cloud" ]; then DONE=$D; break; fi
  done
  if [ -n "$DONE" ] && [ "$RUNNING" -eq 0 ]; then
    echo "[$(date '+%F %T')] 发现结果目录 $DONE，开始渲染" >> "$LOG"
    "$PY" scripts/render_path.py -m "$DONE" --render_path "$DONE/sparse/0" \
        --out_dir "$DONE/video" >> "$LOG" 2>&1
    echo "[$(date '+%F %T')] 渲染退出 rc=$?" >> "$LOG"
    {
      echo "i3dgs 复现结果汇总  $(date '+%F %T')"
      echo "结果目录: $DONE"
      echo "训练日志: $ROOT/logs/train_ds$(basename "$DONE" | sed 's/.*ds//').log"
      echo "--- 点云规模 ---"
      ls -lh "$DONE/point_cloud" 2>/dev/null
      echo "--- 关键日志行 ---"
      grep -iE "psnr|iteration|FPS|fps|time" "$ROOT"/logs/train_ds*.log 2>/dev/null | tail -30
      echo "--- 视频 ---"
      ls -lh "$DONE/video" 2>/dev/null | head
    } > "$ROOT/results/SUMMARY.txt" 2>&1
    echo "[$(date '+%F %T')] SUMMARY 已写出" >> "$LOG"
    break
  fi
  sleep 60
done
