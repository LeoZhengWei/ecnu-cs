#!/bin/bash
# i3dgs 自适应训练看门狗
#   - 轮询 gpu1 空闲显存
#   - >=10GB 用 --downsampling 4，>=6GB 用 --downsampling 8，否则继续等
#   - 失败（含 OOM）自动重试，成功即退出
ROOT=/home/hjadmin/zw/ecnu/ecnv-cg
PY=/home/hjadmin/anaconda3/envs/i3dgs/bin/python
LOG=$ROOT/logs/auto_train.log
mkdir -p "$ROOT/logs"

export CUDA_VISIBLE_DEVICES=1
export TORCH_CUDA_ARCH_LIST="12.0"
export HF_ENDPOINT=https://hf-mirror.com
export HF_HUB_OFFLINE=1
export PYTHONUNBUFFERED=1
export PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True

cd "$ROOT/i3dgs" || exit 1
echo "[$(date '+%F %T')] watchdog started" >> "$LOG"

while true; do
  F=$(nvidia-smi --query-gpu=index,memory.free --format=csv,noheader,nounits | awk -F', ' '$1==1{print $2}')
  F=${F:-0}
  if [ "$F" -ge 10000 ]; then DS=4
  elif [ "$F" -ge 6000 ]; then DS=8
  else
    echo "[$(date '+%T')] gpu1 free=${F}MiB 不足，等待" >> "$LOG"
    sleep 60
    continue
  fi
  echo "[$(date '+%F %T')] gpu1 free=${F}MiB -> 启动 downsampling=$DS" >> "$LOG"
  rm -rf "$ROOT/results/garden_ds$DS"
  "$PY" -u train.py -s "$ROOT/data/MipNeRF360/garden" -m "$ROOT/results/garden_ds$DS" \
      --downsampling "$DS" --da3_model_dir "$ROOT/checkpoints/DA3-BASE" \
      >> "$ROOT/logs/train_ds$DS.log" 2>&1
  RC=$?
  echo "[$(date '+%F %T')] ds=$DS 退出 rc=$RC" >> "$LOG"
  if [ $RC -eq 0 ]; then
    echo "[$(date '+%F %T')] SUCCESS ds=$DS" >> "$LOG"
    break
  fi
  sleep 45
done
